import streamlit as st
import numpy as np
from sklearn.ensemble import RandomForestRegressor

@st.cache_resource
def train_model():
    np.random.seed(42)
    n = 500

    kc_truong    = np.random.uniform(0.2, 5.0, n)
    dien_tich    = np.random.uniform(10, 40, n)
    may_lanh     = np.random.randint(0, 2, n)
    wc_rieng     = np.random.randint(0, 2, n)
    bep          = np.random.randint(0, 2, n)
    gio_tu_do    = np.random.randint(0, 2, n)
    so_nguoi     = np.random.randint(1, 5, n)
    cho_xe       = np.random.randint(0, 2, n)
    gan_tien_ich = np.random.randint(0, 2, n)

    gia = (
        2.5
        + dien_tich * 0.08
        - kc_truong * 0.2
        + may_lanh * 0.5
        + wc_rieng * 0.3
        + bep * 0.2
        + gio_tu_do * 0.15
        - so_nguoi * 0.05
        + cho_xe * 0.2
        + gan_tien_ich * 0.1
        + np.random.normal(0, 0.3, n)
    )
    gia = gia * 1.15
    gia = np.clip(gia, 1.2, 12.0)

    X = np.column_stack([
        kc_truong, dien_tich,
        may_lanh, wc_rieng, bep, gio_tu_do,
        so_nguoi, cho_xe, gan_tien_ich
    ])

    model = RandomForestRegressor(n_estimators=200, random_state=42)
    model.fit(X, gia)
    return model

st.set_page_config(page_title="Dự đoán giá thuê trọ sinh viên", page_icon="🏠", layout="centered")

st.markdown("""
<style>
    .main { background-color: #f8f9fb; }
    .stButton>button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white; border: none; border-radius: 10px;
        padding: 0.6em 2em; font-size: 1.1em; font-weight: 600;
        width: 100%; margin-top: 10px;
    }
    .result-box {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 16px; padding: 30px; text-align: center;
        color: white; margin-top: 20px;
    }
    .result-box h1 { font-size: 3em; margin: 0; }
    .result-box p  { font-size: 1.1em; opacity: 0.9; margin: 5px 0 0; }
    .section-header {
        background: #667eea22; border-left: 4px solid #667eea;
        padding: 8px 14px; border-radius: 4px;
        font-weight: 700; color: #4a4a8a; margin: 18px 0 10px;
    }
</style>
""", unsafe_allow_html=True)

st.title("🏠 Dự đoán giá thuê trọ sinh viên")
st.caption("Nhập thông tin phòng trọ để nhận dự đoán giá thuê hợp lý tại TP.HCM")

model = train_model()

st.markdown('<div class="section-header">📍 Vị trí</div>', unsafe_allow_html=True)
kc_truong = st.number_input("Khoảng cách tới trường (km)", min_value=0.1, max_value=20.0, value=1.0, step=0.1, format="%.1f")

st.markdown('<div class="section-header">🛏️ Thông tin phòng</div>', unsafe_allow_html=True)
col1, col2 = st.columns(2)
with col1:
    dien_tich = st.number_input("Diện tích (m²)", min_value=5, max_value=100, value=20, step=1)
with col2:
    so_nguoi = st.number_input("Số người ở tối đa", min_value=1, max_value=10, value=1, step=1)

st.markdown('<div class="section-header">✨ Tiện nghi</div>', unsafe_allow_html=True)
col3, col4, col5 = st.columns(3)
with col3:
    may_lanh = st.checkbox("❄️ Có máy lạnh")
    wc_rieng = st.checkbox("🚿 WC riêng")
with col4:
    bep    = st.checkbox("🍳 Có bếp")
    cho_xe = st.checkbox("🏍️ Có chỗ để xe")
with col5:
    gio_tu_do    = st.checkbox("🕐 Giờ giấc tự do")
    gan_tien_ich = st.checkbox("🛒 Gần siêu thị / bus")

if st.button("🔍 Dự đoán giá thuê"):
    X_input = np.array([[
        kc_truong, dien_tich,
        int(may_lanh), int(wc_rieng), int(bep), int(gio_tu_do),
        so_nguoi, int(cho_xe), int(gan_tien_ich)
    ]])

    gia_pred = max(model.predict(X_input)[0], 1.2)
    gia_min  = gia_pred * 0.90
    gia_max  = gia_pred * 1.10

    st.markdown(f"""
    <div class="result-box">
        <p>💡 Giá thuê dự đoán</p>
        <h1>{gia_pred:.1f} triệu/tháng</h1>
        <p>Khoảng hợp lý: {gia_min:.1f} – {gia_max:.1f} triệu/tháng</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("📊 Phân tích các yếu tố")

    factors = {
        f"Diện tích {dien_tich}m²":    "+" if dien_tich >= 20 else "-",
        f"Khoảng cách {kc_truong}km":  "-" if kc_truong > 2 else "+",
        "Máy lạnh":     "+" if may_lanh else "~",
        "WC riêng":     "+" if wc_rieng else "~",
        "Bếp":          "+" if bep else "~",
        "Giờ tự do":    "+" if gio_tu_do else "~",
        "Chỗ để xe":    "+" if cho_xe else "~",
        "Gần tiện ích": "+" if gan_tien_ich else "~",
    }

    color_map = {"+": "🟢", "-": "🔴", "~": "⚪"}
    label_map = {"+": "Tăng giá", "-": "Giảm giá", "~": "Không có"}

    rows = "".join(
        f"<tr><td style='padding:7px'>{n}</td><td style='padding:7px'>{color_map[e]} {label_map[e]}</td></tr>"
        for n, e in factors.items()
    )

    st.markdown(f"""
    <table style="width:100%; border-collapse:collapse; font-size:0.95em">
        <thead><tr style="background:#667eea22; font-weight:700">
            <th style="padding:8px; text-align:left">Yếu tố</th>
            <th style="padding:8px; text-align:left">Ảnh hưởng</th>
        </tr></thead>
        <tbody>{rows}</tbody>
    </table>
    """, unsafe_allow_html=True)

    st.info("ℹ️ Kết quả mang tính tham khảo dựa trên mô hình học máy. Giá thực tế có thể dao động tùy thị trường.")

st.markdown("---")
st.caption("Project 1 – App dự đoán giá thuê trọ sinh viên · Dữ liệu mẫu TP.HCM")